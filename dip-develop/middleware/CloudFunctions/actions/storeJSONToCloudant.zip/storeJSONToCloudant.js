/**
  *
  * main() will be run when you invoke this action
  *
  * @param Cloud Functions actions accept a single parameter, which must be a JSON object.
  *
  * @return The output of this action, which must be a JSON object.
  *
  */

function main(params_in_storeJsonToCloudant) {
    console.log("Cloud function storeJSONToCloudant with input params >> " + JSON.stringify(params_in_storeJsonToCloudant));
    var openwhisk = require('openwhisk');
    var hash = require('object-hash');
    const blocking = true, result = true;
    var ow = openwhisk();
    var DEFAULT_VERSION = "1.0";
    var oldVersion = "";
    var newVersion = "";
    var agreement = params_in_storeJsonToCloudant.agreement;
    //Ending add parties
    //Hash new agreement for comparing with the previous verion
    var newAgreementHash = hash(agreement);
    console.log('New Agreement Hash >>>' + JSON.stringify(newAgreementHash));
    //Call to get previous version of agreement.
    var params = {
        sysDetails: params_in_storeJsonToCloudant.sysDetails4Cloudant,
        filter: "filter[_id]=true&filter[_rev]=true&filter[version]=true&filter[hash]=true&filter[agreement]=true&filter[where][agreement.agreementID]=" + agreement.agreementID + "&filter[order]=version:string%20DESC&filter[limit]= 1"
    };
    console.log('Params before calling getNewestAgreementFromCloudant  >>>' + JSON.stringify(params));
    return ow.actions.invoke({ actionName: 'common-ow/getNewestAgreementInCloudant', blocking, result, params }).then(result => {
        console.log("In getting latest Agreement from Cloudant >>> Received the response from getNewestAgreementInCloudant>>> " + JSON.stringify(result));
        var cdAgreement = result.agreements[0];
        console.log('Latest Agreement from Cloudant >>>' + JSON.stringify(cdAgreement));
        if (cdAgreement) {
            //Compare the hash between old and new agreement
            if (newAgreementHash == cdAgreement.hash) {
                //No Change return the newest Agreement from Cloudant
                return { "result": cdAgreement };
            }
            oldVersion = cdAgreement.version;
        }
        console.log('Call write Agreement to Cloudant');
        //Checking version of agreement
        if (oldVersion) {
            newVersion = Number(Number(oldVersion) + 0.1).toFixed(1);
        } else {
            newVersion = DEFAULT_VERSION;
        }
        console.log('New version of Agreement is ' + newVersion);
        var params = {
            sysDetails: params_in_storeJsonToCloudant.sysDetails4Cloudant,
            hash: newAgreementHash,
            body: agreement,
            version: newVersion
        };
        console.log('Param before calling writeAgreementToCloudant  >>>' + JSON.stringify(params));
        //Call to exportAgreement
        return ow.actions.invoke({ actionName: 'common-ow/writeAgreementToCloudant', blocking, result, params }).then(result => {
            console.log("In Write Agreement To Cloudant >>> Received the response from writeAgreementToCloudant>>> " + JSON.stringify(result));
            return { result };
        }).catch(err => {
            console.error('Failed to write Agreement to Cloudant details>>>>', err)
        });

    }).catch(err => {
        console.error('Failed to get latest Agreement from Cloudant details>>>>', err)
    });
}
 exports.main = main;